﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sever : MonoBehaviour {

	// Use this for initialization
	void Start () {
	//开启服务器
    //显示已连接的clients
    //刷新聊天记录
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
