﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class gotoRegister : MonoBehaviour {

	// Use this for initialization
	void Start () {
        this.GetComponent<Button>().onClick.AddListener(click1);
    }
	
	// Update is called once per frame
	void Update () {
		
	}
    public void click1()
    {
        //跳转到注册
        SceneManager.LoadScene("Reigster");
    }
}
